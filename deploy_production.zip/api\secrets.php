<?php
// ARQUIVO DE SEGURANÇA - NÃO COMPARTILHAR
// Este arquivo deve ser protegido via .htaccess se possível

$ADMIN_SECRET = 'Rein@ldo1912';

// Configurações de E-mail (Opcional - Preencher no servidor)
$SMTP_HOST = 'mail.sistemasgestao.com.br';
$SMTP_USER = 'contato@sistemasgestao.com.br';
$SMTP_PASS = 'SuaSenhaEmail';
$SMTP_PORT = 465;

// Mercado Pago (Opcional)
$ACCESS_TOKEN = 'APP_USR-seu-token-aqui';
